WIRED UP STUDIOS / FOSSIL ANIMAL PACK

9 animals. Each glTF contains a weighted skin and 7 animation clips:
Idle, Walk, Flee, Rest, Eat, Drink, Alert.

Rigged/ : glTF with embedded buffers; poses and rig manifest.
Source/ : editable Blockbench (.bbmodel), static OBJ/MTL, palette PNG, rig metadata.
OBJ does not contain animation. Blockbench sources are static editable geometry.
Y-up, facing -Z. Safari static and rigged exports use different scales; see ART-NOTES.txt.
Roblox import and gameplay compatibility have not been verified here.

Original Net & Tame project exports. See ART-NOTES.txt for creation history,
reference-only provenance, units, import guidance, and known limitations.
