WIRED UP STUDIOS / ARCTIC ANIMAL PACK

CC0 1.0 Universal applies to the creator-owned animal assets in this pack.
Commercial use, modification, and redistribution are allowed.
Credit appreciated, never required. See LICENSE.txt for scope and legal terms.

8 animals. Each glTF contains a weighted skin and 7 animation clips:
Idle, Walk, Flee, Rest, Eat, Drink, Alert.

Rigged/ : glTF with embedded buffers; poses and rig manifest.
Source/ : editable Blockbench (.bbmodel), static OBJ/MTL, palette PNG, rig metadata.
OBJ does not contain animation. Blockbench sources are static editable geometry.
Y-up, facing -Z. Safari static and rigged exports use different scales; see ART-NOTES.txt.
Roblox import and gameplay compatibility have not been verified here.

Original Net & Tame project exports. See ART-NOTES.txt for creation history,
reference-only provenance, units, import guidance, and known limitations.
