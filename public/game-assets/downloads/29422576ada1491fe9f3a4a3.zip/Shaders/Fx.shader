Shader "QuestTanks/Fx" {
 // Premultiplied vertex-coloured billboards. UV.xy spans -1..1; floor(UV.z) picks the shape (0 soft disc, 1 thin ring,
 // 2 streak/ribbon with soft edges, 3 lumpy smoke puff, 4 four-point star flare, 5 fireball with a white-hot core) and
 // frac(UV.z) is a per-particle seed that turns each puff so a cloud never repeats.
 Properties { _BaseColor("Tint",Color)=(1,1,1,1) [Enum(UnityEngine.Rendering.BlendMode)] _SrcBlend("Src",Float)=1 [Enum(UnityEngine.Rendering.BlendMode)] _DstBlend("Dst",Float)=10 }
 SubShader { Tags { "Queue"="Transparent" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" "IgnoreProjector"="True" }
 Pass { Blend [_SrcBlend] [_DstBlend] ZWrite Off Cull Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;half4 color:COLOR;float3 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;half4 color:COLOR;float3 uv:TEXCOORD0;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 half4 _BaseColor;float _SrcBlend;float _DstBlend;
 CBUFFER_END
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.color=a.color*_BaseColor;o.uv=a.uv;return o;}
 half Lobe(float2 p,float2 c,float k){return saturate(1-length((p-c)*k));}
 half4 frag(V i):SV_Target {
  UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
  float2 p=i.uv.xy;float id=floor(i.uv.z+.001),seed=frac(i.uv.z);float r=length(p);
  half shape;half3 rgb=i.color.rgb;
  if(id<.5){shape=saturate(1-r);shape*=shape;}
  else if(id<1.5)shape=saturate(1-abs(r-.82)*7);
  else if(id<2.5)shape=saturate(1-abs(p.y))*saturate(1.2-abs(p.x)*.2);
  else if(id<3.5){
   float a=seed*6.2832;float2 q=float2(p.x*cos(a)-p.y*sin(a),p.x*sin(a)+p.y*cos(a));
   half lobes=max(max(Lobe(q,0,1.2),Lobe(q,float2(.38,.22),1.75)),max(max(Lobe(q,float2(-.36,.3),1.8),Lobe(q,float2(.12,-.4),1.9)),Lobe(q,float2(-.32,-.28),2.1)));
   shape=smoothstep(0,.55,lobes);rgb*=.72+.4*saturate(.55+p.y*.5-p.x*.2);}
  else if(id<4.5){half star=saturate(1-abs(p.x)*10)*saturate(1-abs(p.y))+saturate(1-abs(p.y)*10)*saturate(1-abs(p.x));half core=saturate(1-r*1.6);shape=saturate(star*star+core*core);rgb=lerp(rgb,half3(1,1,1),core*.6);}
  else {half core=saturate(1-r);shape=pow(core,.7);rgb=lerp(rgb,half3(1,.95,.78),saturate(1-r*1.9));}
  half a=i.color.a*shape;
  return half4(rgb*a,a);
 }
 ENDHLSL
 }
 }
}
