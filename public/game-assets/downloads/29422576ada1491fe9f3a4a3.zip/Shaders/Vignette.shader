Shader "QuestTanks/Vignette" {
 // Tank cam comfort vignette: a head-locked, vertex-coloured ring drawn over everything else.
 // Vertex alpha shapes the ring (clear at the inner edge, opaque outside); _Strength fades the whole ring in and out.
 Properties { _Strength("Strength",Range(0,1))=0 }
 SubShader { Tags { "Queue"="Overlay" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" "IgnoreProjector"="True" }
 Pass { Blend SrcAlpha OneMinusSrcAlpha ZWrite Off ZTest Always Cull Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;half4 color:COLOR;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;half4 color:COLOR;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 half _Strength;
 CBUFFER_END
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.color=a.color;return o;}
 half4 frag(V i):SV_Target {
  UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
  return half4(i.color.rgb,i.color.a*_Strength);
 }
 ENDHLSL
 }
 }
}
