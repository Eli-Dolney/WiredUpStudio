Shader "QuestTanks/RetroTV" {
 Properties { _Powered("Power",Float)=1 _Clock("Preview time (-1 = live)",Float)=-1 }
 SubShader { Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
 Pass { Tags { "LightMode"="UniversalForward" } Cull Off ZWrite On
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 float _Powered,_Clock;
 CBUFFER_END
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.uv=a.uv;return o;}
 float box(float2 p,float2 c,float2 s){float2 d=abs(p-c)-s;return 1-smoothstep(-.003,.003,max(d.x,d.y));}
 float disc(float2 p,float2 c,float2 r){return 1-smoothstep(.96,1.04,length((p-c)/r));}
 float hash(float2 p){return frac(sin(dot(p,float2(127.1,311.7)))*43758.5453);}
 half4 frag(V i):SV_Target {
  UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
  float2 glass=i.uv*2-1;float edge=1-smoothstep(.91,1.04,max(abs(glass.x),abs(glass.y)));
  if(_Powered<.5)return half4(.008,.014,.017,1);
  float t=fmod(floor((_Clock<0?_Time.y:_Clock)*24)/24,18);
  float2 uv=i.uv+glass*dot(glass,glass)*.012;uv=floor(uv*float2(192,144))/float2(192,144);
  float3 color=lerp(float3(.055,.10,.21),float3(.12,.26,.38),1-uv.y);
  // Original silent cartoon: a delivery rocket cruises over a moon landscape.
  float2 stars=uv*float2(16,12)+float2(t*.12,0);float2 cell=floor(stars);float seed=hash(cell);
  float star=disc(frac(stars),float2(.2+.5*seed,.25+.4*seed),float2(.035,.045))*step(.60,seed)*step(.26,uv.y);
  color=lerp(color,float3(.88,.86,.63),star*(.70+.12*sin(t+seed*5)));
  float planet=disc(uv,float2(.76,.71),float2(.125,.167));
  float bands=.5+.5*sin(uv.y*95+sin(uv.x*24+t*.10)*.6);
  color=lerp(color,lerp(float3(.26,.48,.43),float3(.46,.65,.47),bands),planet);
  float ring=abs(length((uv-float2(.76,.71))/float2(.19,.052))-1);
  color=lerp(color,float3(.79,.60,.35),(1-smoothstep(.04,.13,ring))*step(uv.y,.73));
  float farH=.18+.035*sin(uv.x*12+t*.14)+.018*sin(uv.x*25-t*.07);
  color=lerp(color,float3(.23,.27,.36),1-smoothstep(farH,farH+.006,uv.y));
  float ground=.105+.025*sin(uv.x*14+t*.24);
  color=lerp(color,float3(.43,.34,.33),1-smoothstep(ground,ground+.007,uv.y));
  // A little moon outpost, with warm lit windows and a slow orbiting satellite.
  color=lerp(color,float3(.53,.62,.61),box(uv,float2(.16,.185),float2(.075,.035)));
  color=lerp(color,float3(.94,.68,.34),box(uv,float2(.13,.19),float2(.012,.012))+box(uv,float2(.18,.19),float2(.012,.012)));
  float2 satellite=float2(.76+sin(t*.28)*.19,.71+cos(t*.28)*.07);
  color=lerp(color,float3(.64,.76,.78),box(uv,satellite,float2(.012,.012)));
  color=lerp(color,float3(.30,.50,.67),box(uv,satellite+float2(.026,0),float2(.014,.006))+box(uv,satellite-float2(.026,0),float2(.014,.006)));
  float2 rocket=float2(frac(t/18)*1.40-.2,.43+.06*sin(t*.65));float2 p=uv-rocket;
  float flame=disc(p,float2(-.092,0),float2(.044+.005*sin(t*14),.018));
  color=lerp(color,float3(.96,.55,.19),flame);
  color=lerp(color,float3(1,.82,.38),disc(p,float2(-.082,0),float2(.032,.009)));
  color=lerp(color,float3(.78,.32,.26),box(p,float2(-.034,0),float2(.046,.026)));
  float nose=step(0,p.x)*step(p.x,.06)*step(abs(p.y),(.06-p.x)*.45);
  color=lerp(color,float3(.88,.83,.66),nose);
  float fin=step(-.08,p.x)*step(p.x,-.02)*step(abs(p.y),.052)*step(abs(p.y),.025+(-p.x-.02)*.60);
  color=lerp(color,float3(.85,.57,.32),fin);
  color=lerp(color,float3(.13,.25,.34),disc(p,float2(-.005,0),float2(.020,.026)));
  color=lerp(color,float3(.53,.82,.82),disc(p,float2(-.005,0),float2(.013,.018)));
  color+=float3(.12,.16,.14)*disc(p,float2(.001,.007),float2(.005,.006));
  // Quiet scanlines and curved dark edges, without bright flashes or static bursts.
  float scan=.96+.04*sin(i.uv.y*144*6.2831853);
  float vignette=1-.18*dot(glass,glass);color*=scan*vignette*edge;
  color+=float3(.018,.028,.036)*(1-i.uv.y)*edge;
  return half4(color,1);
 }
 ENDHLSL
 }
 }
}
