Shader "QuestTanks/Terrain" {
 Properties { _BaseColor("Color",Color)=(1,1,1,1) _Set("Terrain set",Float)=1 _Floor("Floor",Float)=0 _Breakable("Breakable",Float)=0 }
 SubShader { Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
 Pass { Tags { "LightMode"="UniversalForward" }
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;float3 normalOS:NORMAL;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;float3 normal:TEXCOORD0;float3 board:TEXCOORD1;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 float4 _BaseColor;float _Set;float _Floor;float _Breakable;
 CBUFFER_END
 // North Pole night: 0 day, 1 dusk (set globally by BattleView.SetFestive), matching the Toy shader.
 float _BoardNight;
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.normal=a.normalOS;o.board=a.positionOS.xyz;return o;}
 half4 frag(V i):SV_Target {
   UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
   float2 p=i.board.xz;float hash=frac(sin(dot(floor(p*19),float2(12.9898,78.233)))*43758.5453);
   half top=smoothstep(.4,.85,i.normal.y);half3 c=half3(.51,.66,.36);
   if(_Set<1.5){c=lerp(half3(.44,.30,.19),half3(.43,.61,.29),top);if(_Floor>.5)c=half3(.51,.66,.36);c+=(hash-.5)*.045;}
   else if(_Set<2.5){c=lerp(half3(.49,.68,.75),half3(.88,.95,.94),top);if(_Floor>.5)c=half3(.80,.88,.90);c+=(hash-.5)*.028;}
   else if(_Set<3.5){float dunes=sin(p.x*6+sin(p.y*2)*.8)*.015;c=lerp(half3(.65,.44,.24),half3(.84,.67,.38),top);if(_Floor>.5)c=half3(.84,.70,.44);c+=dunes+(hash-.5)*.025;}
   else if(_Set<4.5){c=lerp(half3(.20,.42,.51),half3(.39,.65,.71),top);if(_Floor>.5){c=half3(.63,.68,.58);float seam=step(.985,frac(p.x));c*=1-seam*.12;}}
   else if(_Set<5.5){float h=fmod(floor(p.x)*3+floor(p.y)*7,4);c=h<.5?half3(.81,.13,.10):h<1.5?half3(.08,.46,.66):h<2.5?half3(.94,.75,.08):half3(.13,.60,.27);if(_Floor>.5){c=lerp(half3(.84,.79,.65),c,.065);}}
   // Moon: grey regolith with scattered craters, darker bowls and bright rims.
   else{c=lerp(half3(.38,.40,.45),half3(.68,.70,.74),top);if(_Floor>.5){c=half3(.62,.64,.68);float2 q=p/2.6;float2 f=frac(q)-.5;float r=length(f);float pick=frac(sin(dot(floor(q),float2(7.13,3.71)))*913.7);if(pick>.45){float size=.18+pick*.14;c-=.09*smoothstep(size,size*.4,r);c+=.07*smoothstep(.035,0,abs(r-size));}}c+=(hash-.5)*.04;}
   // Keep breakable blocks recognisable across every collection.
   float2 cell=abs(frac(p)-.5);half cross=1-step(.045,min(cell.x,cell.y));
   if(_Breakable>.5)c=lerp(c,half3(.96,.80,.59),top*cross*.85);
   half grain=sin(i.board.x*42+sin(i.board.z*3)*1.5)*.006;
   half light=.62+.38*saturate(dot(normalize(i.normal),normalize(half3(-.4,1,-.5))));
   return half4(saturate(c+grain)*light*lerp(half3(1,1,1),half3(.66,.74,.95),_BoardNight),1);
 }
 ENDHLSL
 }
 }
}
