Shader "QuestTanks/Water" {
 Properties { _BaseColor("Water tint",Color)=(0.75,1,1,1) _Clock("Preview clock (-1 = live)",Float)=-1 }
 SubShader { Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
 Pass { Tags { "LightMode"="UniversalForward" }
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;float3 normalOS:NORMAL;half4 color:COLOR;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;float3 normal:TEXCOORD0;float3 board:TEXCOORD1;half4 color:COLOR;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 float4 _BaseColor;float _Clock;
 CBUFFER_END
 V vert(A a) {V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.normal=a.normalOS;o.board=a.positionOS.xyz;o.color=a.color;return o;}
 half4 frag(V i):SV_Target {
   UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
   // Combined meshes retain board coordinates. Ripples stay the same size when
   // the player scales or rotates the arena; no transparency or scene sampling.
   float clock=_Clock<0?_Time.y:_Clock;
   float wave=sin(i.board.z*11+i.board.x*.8+sin(i.board.x*4.3+clock*.6)*1.2-clock*.8);
   half foam=smoothstep(.92,.995,wave)*saturate(i.normal.y)*.23*(.15+.85*smoothstep(-.2,.4,sin(i.board.x*3.7+i.board.z*1.2+clock*.25)));
   half light=.65+.35*saturate(dot(normalize(i.normal),normalize(half3(-.4,1,-.5))));
   return half4(lerp(i.color.rgb*_BaseColor.rgb*light,half3(.65,.92,.91),foam),1);
 }
 ENDHLSL
 }
 }
}
