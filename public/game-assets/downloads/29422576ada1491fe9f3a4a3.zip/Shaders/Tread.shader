Shader "QuestTanks/Tread" {
 Properties { _BaseColor("Color",Color)=(0.22,0.14,0.075,0.4) _Lifetime("Lifetime",Float)=25 }
 SubShader { Tags { "Queue"="Transparent-10" "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" }
 Pass { Blend SrcAlpha OneMinusSrcAlpha ZWrite Off
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;float2 uv:TEXCOORD0;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;half alpha:TEXCOORD0;half4 tint:TEXCOORD1;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 half4 _BaseColor;float _Lifetime;
 CBUFFER_END
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.positionCS=TransformObjectToHClip(a.positionOS.xyz);o.alpha=saturate((_Lifetime-(_Time.y-a.uv.x))/5);
  // Garage tread colours by style (UV0.y): 0 walnut (material colour), 1 chalk, 2 glow, 3 rainbow by stamp time, 4 gold, 5 snow.
  int style=(int)(a.uv.y+.5);half3 hue=saturate(abs(frac(a.uv.x*.35+half3(0,.333,.667))*6-3)-1);
  o.tint=style==1?half4(.95,.93,.88,.55):style==2?half4(.35,1,1,.8):style==3?half4(hue,.7):style==4?half4(1,.78,.25,.65):style==5?half4(.86,.93,1,.6):_BaseColor;return o;}
 half4 frag(V i):SV_Target {UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);return half4(i.tint.rgb,i.tint.a*i.alpha);}
 ENDHLSL
 }
 }
}
