Shader "QuestTanks/Sky" {
 // Procedural skies on a camera-centred box, drawn at the far plane after opaque geometry so only open sky pays for it.
 // _Style: 1 deep space, 2 golden hour, 3 aurora, 4 candy clouds, 5 thunderstorm, 6 clear day, 7 synthwave. _Yaw turns the sky with the room.
 Properties { _Style("Style",Float)=1 _Yaw("Yaw",Float)=0 }
 SubShader { Tags { "Queue"="Geometry+400" "RenderType"="Background" "RenderPipeline"="UniversalPipeline" "PreviewType"="Skybox" }
 Pass { Tags { "LightMode"="UniversalForward" } Cull Off ZWrite Off ZTest LEqual
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;float3 dir:TEXCOORD0;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 float _Style;float _Yaw;
 CBUFFER_END
 V vert(A a){V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);float3 w=TransformObjectToWorld(a.positionOS.xyz);o.positionCS=TransformWorldToHClip(w);o.positionCS.z=UNITY_RAW_FAR_CLIP_VALUE*o.positionCS.w;
  float3 d=w-GetCameraPositionWS();float c=cos(_Yaw),s=sin(_Yaw);o.dir=float3(d.x*c-d.z*s,d.y,d.x*s+d.z*c);return o;}
 float Hash(float3 p){p=frac(p*.3183099+.1);p*=17;return frac(p.x*p.y*p.z*(p.x+p.y+p.z));}
 float Noise(float3 x){float3 i=floor(x),f=frac(x);f=f*f*(3-2*f);return lerp(lerp(lerp(Hash(i),Hash(i+float3(1,0,0)),f.x),lerp(Hash(i+float3(0,1,0)),Hash(i+float3(1,1,0)),f.x),f.y),lerp(lerp(Hash(i+float3(0,0,1)),Hash(i+float3(1,0,1)),f.x),lerp(Hash(i+float3(0,1,1)),Hash(i+float3(1,1,1)),f.x),f.y),f.z);}
 float Stars(float3 d,float density,float t){float3 g=d*190;float3 c=floor(g);float h=Hash(c);float3 q=frac(g)-.5;float b=step(1-density,h)*saturate(1-length(q)*2.6);return b*b*(.55+.45*sin(t*2.3+h*80));}
 // Unit-disc coordinates around a direction; z is 0 outside.
 float3 Disc(float3 d,float3 at,float radius){float3 r=normalize(cross(float3(0,1,0),at)),u=cross(at,r);float2 p=float2(dot(d,r),dot(d,u))/radius;float k=dot(p,p);return float3(p,dot(d,at)>0&&k<1?sqrt(1-k):0);}
 half3 Space(float3 d,float t){
  half3 c=lerp(half3(.008,.01,.03),half3(.03,.02,.07),saturate(d.y*.5+.5));
  float n=Noise(d*2.6)*.6+Noise(d*5.3+7)*.4;c+=half3(.38,.07,.46)*pow(saturate(n-.38),2)*3+half3(.04,.2,.42)*pow(saturate(Noise(d*3.1+3)-.42),2)*3;
  float band=exp(-pow(dot(d,normalize(float3(.35,1,.15))),2)*16);c+=half3(.45,.42,.6)*band*(.25+.35*Noise(d*11));
  c+=Stars(d,.012+band*.02,t)*half3(1,.97,.9);
  float3 at=normalize(float3(.42,.20,1));float3 p=Disc(d,at,.24);float ringR=length(float2(p.x,(p.y-p.x*.28)*3.4));
  half ring=step(1.3,ringR)*step(ringR,2.15)*(.55+.45*sin(ringR*38))*step(dot(d,at),1)*step(.8,dot(d,at));
  if(p.z>0){float3 nrm=float3(p.x,p.y,p.z);half lit=saturate(dot(nrm,normalize(float3(-.65,.45,.55))));half bands=.5+.5*sin(p.y*16+Noise(float3(p.xy*3,1))*2.5);
   half3 body=lerp(half3(.86,.5,.26),half3(.98,.84,.62),bands);c=body*(.05+lit*.95)+half3(.3,.55,1)*pow(1-p.z,3)*(.2+lit);if(p.y-p.x*.28>0)ring=0;}
  c=lerp(c,half3(.86,.78,.66)*(.35+.65*saturate(p.x*-.5+.6)),ring*.8);
  float3 m=Disc(d,normalize(float3(-.55,.42,.9)),.035);if(m.z>0)c=half3(.75,.76,.8)*(.25+.75*saturate(dot(float3(m.x,m.y,m.z),normalize(float3(-.65,.45,.55)))))*(1-.15*Noise(float3(m.xy*6,3)));
  return c;}
 half3 Sunset(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(1,.58,.28),half3(.86,.38,.46),smoothstep(0,.22,y));c=lerp(c,half3(.2,.16,.4),smoothstep(.18,.8,y));
  float3 sun=normalize(float3(-.15,.07,1));float g=saturate(dot(d,sun));c+=half3(1,.62,.3)*pow(g,10)*.7+half3(1,.92,.72)*smoothstep(.9988,.9993,g)*1.6;
  if(y>0){float2 uv=d.xz/(y+.1);float n=Noise(float3(uv*1.3+float2(t*.008,0),2))*.65+Noise(float3(uv*3.1,5))*.35;half cl=smoothstep(.52,.72,n)*smoothstep(0,.12,y);
   c=lerp(c,lerp(half3(1,.74,.55),half3(.6,.32,.48),saturate(y*2.2))+half3(.4,.2,.05)*pow(g,4),cl*.75);}
  float az=atan2(d.x,d.z);float hill=.035+.025*Noise(float3(az*2.2,0,0))+.02*Noise(float3(az*7,1,0));
  if(y<hill)c=lerp(half3(.32,.17,.26),half3(.12,.07,.12),saturate((hill-y)*6));
  return c;}
 half3 Aurora(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(.02,.05,.08),half3(.005,.015,.04),saturate(y));c+=Stars(d,.016,t)*half3(.9,.95,1);
  if(y>0){float az=atan2(d.x,d.z);for(int k=0;k<2;k++){float w=Noise(float3(az*2.5+k*3,t*.12,k));float h=.32+k*.16+.1*sin(az*2+t*.15+k)+.08*w;float curtain=exp(-pow((y-h)*(k?7:5),2))*smoothstep(h+.25,h-.05,y);
   float streak=.55+.45*sin(az*55+Noise(float3(az*9,t*.3,k))*7);c+=lerp(half3(.08,1,.52),half3(.62,.22,1),saturate((y-h+.06)*4))*curtain*streak*(.75-k*.25);}}
  float az2=atan2(d.x,d.z);float mtn=.03+.05*abs(sin(az2*3.1))+.025*Noise(float3(az2*9,2,0));
  if(y<mtn)c=lerp(half3(.12,.15,.2),half3(.03,.04,.06),saturate((mtn-y)*5));
  return c;}
 half3 Candy(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(1,.76,.86),half3(.58,.8,1),smoothstep(-.1,.7,y));if(y<0)c=lerp(c,half3(.82,.72,1),saturate(-y*3));
  float n=Noise(d*2.6+float3(t*.02,0,0))*.6+Noise(d*6.2+1)*.4;half puff=smoothstep(.5,.6,n);c=lerp(c,lerp(half3(1,.98,1),half3(1,.78,.9),saturate(.65-n)*2),puff*.92);
  c+=Stars(d,.006,t*1.6)*half3(1,1,1)*.8;return c;}
 half3 Storm(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(.16,.18,.22),half3(.07,.08,.11),saturate(y*1.4));
  float n=Noise(d*float3(2,3.5,2)+float3(t*.06,0,t*.03))*.6+Noise(d*6+float3(t*.12,0,0))*.4;c=lerp(c*.7,half3(.27,.29,.34),n);
  float k=floor(t*.6);float flash=step(.72,Hash(float3(k,1,3)))*pow(saturate(1-frac(t*.6)*5),2);float3 at=normalize(float3(Hash(float3(k,2,1))*2-1,.4,Hash(float3(k,3,1))*2-1));
  c+=half3(.55,.6,.85)*flash*(.35+n)*(.4+.6*saturate(dot(d,at)));
  float bolt=flash*step(.98,1-abs(dot(normalize(cross(at,float3(0,1,0))),d)+.04*sin(d.y*60+k)))*step(0,d.y)*step(d.y,at.y+.05);c+=half3(.85,.9,1)*bolt;
  if(y<0)c=lerp(c,half3(.05,.06,.07),saturate(-y*5));return c;}
 half3 Day(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(.78,.88,1),half3(.24,.5,.92),smoothstep(0,.7,y));
  float3 sun=normalize(float3(.45,.62,.7));float g=saturate(dot(d,sun));c+=half3(1,.95,.8)*(pow(g,40)*.4+smoothstep(.9992,.9995,g)*1.5);
  if(y>0){float2 uv=d.xz/(y+.15);float n=Noise(float3(uv*1.1+float2(t*.01,0),4))*.6+Noise(float3(uv*2.7,8))*.4;c=lerp(c,half3(1,1,1),smoothstep(.55,.72,n)*smoothstep(0,.15,y)*.85);}
  float az=atan2(d.x,d.z);float hill=.02+.03*Noise(float3(az*3,0,0));if(y<hill)c=lerp(half3(.42,.62,.46),half3(.2,.36,.28),saturate((hill-y)*4));
  return c;}
 half3 Synth(float3 d,float t){
  float y=d.y;half3 c=lerp(half3(1,.3,.58),half3(.24,.05,.36),smoothstep(0,.35,y));c=lerp(c,half3(.04,.01,.1),smoothstep(.3,.9,y));c+=Stars(d,.01,t)*half3(1,.85,1)*smoothstep(.2,.5,y);
  float3 p=Disc(d,normalize(float3(0,.13,1)),.26);if(p.z>0){half stripe=p.y<.1&&frac(p.y*6)<.42-p.y*.4?0:1;c=lerp(c,lerp(half3(1,.25,.55),half3(1,.92,.35),saturate(p.y*.5+.5)),stripe);}
  if(y<0){float2 uv=d.xz/max(-y,.002);uv.y+=t*1.5;float2 f=abs(frac(uv*.5)-.5)*2;half grid=max(smoothstep(.9,1,f.x),smoothstep(.9,1,f.y));half fade=saturate(-y*7);
   c=half3(.05,0,.09)+half3(1,.2,.85)*grid*fade+half3(1,.3,.6)*exp(y*25)*.7;}
  return c;}
 half4 frag(V i):SV_Target {UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
  float3 d=normalize(i.dir);float t=_Time.y;int s=(int)(_Style+.5);half3 c;
  if(s==1)c=Space(d,t);else if(s==2)c=Sunset(d,t);else if(s==3)c=Aurora(d,t);else if(s==4)c=Candy(d,t);else if(s==5)c=Storm(d,t);else if(s==6)c=Day(d,t);else c=Synth(d,t);
  return half4(c*c,1);} // Authored as display colours; the project renders in linear space.
 ENDHLSL
 }
 }
}
