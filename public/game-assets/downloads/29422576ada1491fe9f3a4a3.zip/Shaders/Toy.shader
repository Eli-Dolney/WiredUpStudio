Shader "QuestTanks/Toy" {
 Properties { _BaseColor("Color",Color)=(1,1,1,1) _Grain("Wood grain",Float)=0 _VertexPaint("Vertex paint",Float)=0 }
 SubShader { Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" }
 Pass { Tags { "LightMode"="UniversalForward" }
 HLSLPROGRAM
 #pragma vertex vert
 #pragma fragment frag
 #pragma multi_compile_instancing
 #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
 struct A {float4 positionOS:POSITION;float3 normalOS:NORMAL;half4 color:COLOR;float4 extra:TEXCOORD1;UNITY_VERTEX_INPUT_INSTANCE_ID};
 struct V {float4 positionCS:SV_POSITION;float3 normal:TEXCOORD0;float3 pos:TEXCOORD1;float3 world:TEXCOORD2;half4 extra:TEXCOORD3;half4 color:COLOR;UNITY_VERTEX_OUTPUT_STEREO};
 CBUFFER_START(UnityPerMaterial)
 float4 _BaseColor;float _Grain;float _VertexPaint;
 CBUFFER_END
 // The local player's Garage pattern (0 solid) and its second colour, set globally by the game.
 float _TankPattern;float4 _TankAccent;
 // North Pole night: 0 day, 1 dusk (set globally by BattleView.SetFestive).
 float _BoardNight;
 V vert(A a) {V o;UNITY_SETUP_INSTANCE_ID(a);UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);o.world=TransformObjectToWorld(a.positionOS.xyz);o.positionCS=TransformWorldToHClip(o.world);o.normal=TransformObjectToWorldNormal(a.normalOS);o.pos=a.positionOS.xyz;o.color=a.color;o.extra=a.color.a<.01?a.extra:0;return o;}
 float Hash(float3 p){p=frac(p*.3183099+.1);p*=17;return frac(p.x*p.y*p.z*(p.x+p.y+p.z));}
 float Noise(float3 x){float3 i=floor(x),f=frac(x);f=f*f*(3-2*f);return lerp(lerp(lerp(Hash(i),Hash(i+float3(1,0,0)),f.x),lerp(Hash(i+float3(0,1,0)),Hash(i+float3(1,1,0)),f.x),f.y),lerp(lerp(Hash(i+float3(0,0,1)),Hash(i+float3(1,0,1)),f.x),lerp(Hash(i+float3(0,1,1)),Hash(i+float3(1,1,1)),f.x),f.y),f.z);}
 // Patterns in model space (one tank is about one unit): 1 racing stripes, 2 camo, 3 tiger, 4 checker, 5 flames, 6 digital, 7 galaxy, 8 two-tone, 9 hazard, 10 candy cane (its own red and white).
 half3 Pattern(half3 body,float3 p){
  half3 accent=_TankAccent.rgb;int id=(int)(_TankPattern+.5);
  if(id==1)return abs(abs(p.x)-.075)<.032?accent:body;
  if(id==2){float n=Noise(p*7.5)*.65+Noise(p*16+3.1)*.35;return n<.4?body*.5:n>.6?accent:body;}
  if(id==3){float s=sin(p.z*36+sin(p.x*13+p.y*9)*1.8+p.y*10);return s>.55?lerp(body,half3(.02,.02,.025),.85):body;}
  if(id==4){float3 c=floor(p*11+.5);return fmod(abs(c.x+c.y+c.z),2)<1?accent:body;}
  if(id==5){float t=p.z+.07*sin(p.x*34+p.y*20)+.09*Noise(p*14);return t>.08?lerp(accent,half3(1,.86,.25),saturate((t-.08)*5)):body;}
  if(id==6){float h=Hash(floor(p*24));return h<.3?body*.55:h>.72?accent:body;}
  if(id==7){half3 nebula=lerp(body,accent,saturate(Noise(p*5)*1.6-.35));return Hash(floor(p*60))>.975?half3(1.6,1.6,1.7):nebula;}
  if(id==8)return p.y>.3?accent:body;
  if(id==9)return sin((p.x+p.z)*42)>0?accent:body*.25;
  if(id==10)return frac((p.x+p.y+p.z)*5.5)<.5?half3(.60,.03,.03):half3(.90,.90,.86);
  if(id==11){float3 c=frac(p*9)-.5;return dot(c.xz,c.xz)<.07?accent:body;}
  if(id==12)return sin(p.x*30+sin(p.z*8)*2.2)>.35?half3(.05,.05,.06):body;
  return body;}
 half4 frag(V i):SV_Target {UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
  half3 n=normalize(i.normal);half3 light=normalize(half3(-.4,1,-.5));half l=.62+.38*saturate(dot(n,light));half grain=sin(i.pos.x*42+sin(i.pos.z*3)*1.5)*.009+sin(i.pos.x*11+i.pos.z*.4)*.014;
  half3 base=_BaseColor.rgb*lerp(half3(1,1,1),i.color.rgb,_VertexPaint);
  if(i.extra.z>.5&&_TankPattern>.5)base=Pattern(base,i.pos);
  half3 color=base*(l+grain*_Grain);
  // Blender models: a glossy highlight, a cool rim that lifts silhouettes off the board, and self-lit lamps.
  if(i.color.a<.01){half3 v=GetWorldSpaceNormalizeViewDir(i.world);half gloss=i.extra.x;half spec=pow(saturate(dot(n,normalize(light+v))),10+gloss*70)*gloss*.6;half rim=pow(1-saturate(dot(n,v)),3);
   color+=spec+rim*(.10+.12*gloss)*half3(.85,.93,1);color=lerp(color,base*1.35,i.extra.y);}
  color*=lerp(half3(1,1,1),half3(.66,.74,.95),_BoardNight*(1-i.extra.y));
  return half4(color,1);}
 ENDHLSL
 }
 }
}
