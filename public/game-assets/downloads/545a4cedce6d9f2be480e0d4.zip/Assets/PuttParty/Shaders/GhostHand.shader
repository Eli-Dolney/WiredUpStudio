// Translucent hand with a glowing outline (the look of the headset's own system hands).
// A depth-only pass first, so fingers in front hide fingers behind instead of doubling up;
// then a fill that is faint face-on and bright at grazing angles. Cull Off so the mirrored
// left hand (negative scale) renders too.
Shader "PuttParty/GhostHand"
{
    Properties
    {
        _FillColor ("Fill", Color) = (0.72, 0.84, 1, 0.14)
        _RimColor ("Outline", Color) = (0.86, 0.95, 1, 1)
        _RimPower ("Outline Sharpness", Float) = 2.6
    }
    SubShader
    {
        Tags { "RenderType"="Transparent" "RenderPipeline"="UniversalPipeline" "Queue"="Transparent+10" }
        Cull Off

        Pass
        {
            Name "Depth"
            Tags { "LightMode"="SRPDefaultUnlit" }
            ZWrite On
            ColorMask 0
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            struct Attributes { float4 positionOS : POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings { float4 positionHCS : SV_POSITION; UNITY_VERTEX_OUTPUT_STEREO };

            Varyings vert (Attributes IN)
            {
                Varyings OUT;
                UNITY_SETUP_INSTANCE_ID(IN);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(OUT);
                OUT.positionHCS = TransformObjectToHClip(IN.positionOS.xyz);
                return OUT;
            }

            half4 frag (Varyings IN) : SV_Target { return 0; }
            ENDHLSL
        }

        Pass
        {
            Name "Forward"
            Tags { "LightMode"="UniversalForward" }
            ZWrite Off
            ZTest LEqual
            Blend SrcAlpha OneMinusSrcAlpha
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _FillColor;
                half4 _RimColor;
                float _RimPower;
            CBUFFER_END

            struct Attributes { float4 positionOS : POSITION; float3 normalOS : NORMAL; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings { float4 positionHCS : SV_POSITION; float3 normalWS : TEXCOORD0; float3 viewWS : TEXCOORD1; UNITY_VERTEX_OUTPUT_STEREO };

            Varyings vert (Attributes IN)
            {
                Varyings OUT;
                UNITY_SETUP_INSTANCE_ID(IN);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(OUT);
                float3 positionWS = TransformObjectToWorld(IN.positionOS.xyz);
                OUT.positionHCS = TransformWorldToHClip(positionWS);
                OUT.normalWS = TransformObjectToWorldNormal(IN.normalOS);
                OUT.viewWS = GetWorldSpaceViewDir(positionWS);   // per eye in single-pass stereo
                return OUT;
            }

            half4 frag (Varyings IN) : SV_Target
            {
                // abs(): with Cull Off and a mirrored hand, back faces still get an outline at the silhouette.
                float facing = abs(dot(normalize(IN.normalWS), normalize(IN.viewWS)));
                float rim = pow(saturate(1.0 - facing), _RimPower);
                half3 color = lerp(_FillColor.rgb, _RimColor.rgb, rim);
                half alpha = saturate(_FillColor.a + rim * _RimColor.a);
                return half4(color, alpha);
            }
            ENDHLSL
        }
    }
}
