// The golf ball's look: two colours in a pattern drawn on the sphere from its object-space normal
// (no textures), lit by the main light with a glossy highlight and a soft rim, plus optional glow.
// Patterns: 0 solid, 1 stripe, 2 halves, 3 dots, 4 checker, 5 beach-ball segments, 6 swirl, 7 gradient,
// 8 stars, 9 planet bands, 10 marble, 11 football patches, 12 flames (animated), 13 rainbow (animated).
Shader "PuttParty/BallSkin"
{
    Properties
    {
        _ColorA ("Colour A", Color) = (1, 1, 1, 1)
        _ColorB ("Colour B", Color) = (1, 1, 1, 1)
        _Pattern ("Pattern", Float) = 0
        _Glow ("Glow", Range(0, 1)) = 0.15
        _Shine ("Shine", Range(0, 1)) = 0.5
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" "Queue"="Geometry" }

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode"="UniversalForward" }
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"

            CBUFFER_START(UnityPerMaterial)
                half4 _ColorA, _ColorB;
                float _Pattern;
                half _Glow, _Shine;
            CBUFFER_END

            struct Attributes { float4 positionOS : POSITION; float3 normalOS : NORMAL; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings
            {
                float4 positionHCS : SV_POSITION;
                float3 positionWS : TEXCOORD0;
                float3 normalWS : TEXCOORD1;
                float3 normalOS : TEXCOORD2;
                half fog : TEXCOORD3;
                UNITY_VERTEX_OUTPUT_STEREO
            };

            Varyings vert (Attributes IN)
            {
                Varyings OUT;
                UNITY_SETUP_INSTANCE_ID(IN);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(OUT);
                OUT.positionWS = TransformObjectToWorld(IN.positionOS.xyz);
                OUT.positionHCS = TransformWorldToHClip(OUT.positionWS);
                OUT.normalWS = TransformObjectToWorldNormal(IN.normalOS);
                OUT.normalOS = IN.normalOS;
                OUT.fog = ComputeFogFactor(OUT.positionHCS.z);
                return OUT;
            }

            // 0 = colour A, 1 = colour B.
            half Mask(float3 n)
            {
                float lat = asin(clamp(n.y, -1, 1));             // -pi/2 .. pi/2
                float lon = atan2(n.z, n.x);                      // -pi .. pi
                int p = (int)round(_Pattern);
                if (p == 1) return step(abs(n.y), 0.3);
                if (p == 2) return step(0, n.y);
                if (p == 3)
                {
                    float2 g = float2(lon * 3.0 / PI, lat * 4.0 / PI);
                    return step(length(frac(g) - 0.5), 0.26);
                }
                if (p == 4)
                {
                    float2 g = floor(float2(lon * 4.0 / PI, lat * 4.0 / PI));
                    return fmod(abs(g.x + g.y), 2.0);
                }
                if (p == 5)
                {
                    if (abs(n.y) > 0.88) return 0.5;               // white caps
                    return fmod(floor((lon + PI) / (PI / 3.0)), 2.0);
                }
                if (p == 6) return step(0, sin(lon * 2.0 + lat * 5.0));
                if (p == 7) return saturate(n.y * 0.6 + 0.5);
                if (p == 8)
                {
                    // Five-pointed stars on a grid.
                    float2 q = frac(float2(lon * 3.0 / PI, lat * 4.0 / PI)) - 0.5;
                    float a = atan2(q.y, q.x);
                    return step(length(q), 0.2 + 0.11 * cos(a * 5.0 + 1.5708));
                }
                if (p == 9) return step(0, sin(lat * 9.0));        // planet bands
                if (p == 10)
                {
                    // Marble veins: a sine warped by a few more.
                    float t = n.x * 3.1 + sin(n.y * 5.0 + sin(n.z * 4.0) * 1.7) * 1.3 + sin(n.z * 7.0 + n.x * 3.0) * 0.6;
                    return smoothstep(-0.25, 0.25, sin(t * 3.0));
                }
                if (p == 11)
                {
                    // Football patches: a round patch at each of the 12 corners of an icosahedron.
                    float3 a = abs(n);
                    float d = max(dot(a, float3(0, 0.5257, 0.8507)), max(dot(a, float3(0.5257, 0.8507, 0)), dot(a, float3(0.8507, 0, 0.5257))));
                    return step(0.93, d);
                }
                if (p == 12)
                {
                    // Flames licking up from the bottom, flickering.
                    float edge = 0.1 + 0.3 * sin(lon * 6.0 + _Time.y * 2.5) * sin(lon * 2.0 + 1.0) + 0.08 * sin(lon * 13.0 - _Time.y * 4.0);
                    return smoothstep(-0.08, 0.08, n.y - edge);
                }
                return 0;
            }

            half3 Hue(float h)
            {
                return saturate(abs(frac(h + float3(0, 2.0 / 3.0, 1.0 / 3.0)) * 6.0 - 3.0) - 1.0);
            }

            half4 frag (Varyings IN) : SV_Target
            {
                float3 nOS = normalize(IN.normalOS);
                int pattern = (int)round(_Pattern);
                half m = Mask(nOS);
                half3 albedo = (pattern == 5 && m == 0.5) ? half3(0.97, 0.97, 0.95) : lerp(_ColorA.rgb, _ColorB.rgb, m);
                // 13: a rainbow that slowly turns round the ball, washed toward colour A.
                if (pattern == 13) albedo = lerp(Hue(atan2(nOS.z, nOS.x) / (2.0 * PI) + nOS.y * 0.35 + _Time.y * 0.08), _ColorA.rgb, 0.15);

                half3 n = normalize(IN.normalWS);
                half3 v = normalize(GetWorldSpaceViewDir(IN.positionWS));
                Light main = GetMainLight(TransformWorldToShadowCoord(IN.positionWS));
                half shadow = main.shadowAttenuation * main.distanceAttenuation;
                half3 lit = main.color * saturate(dot(n, main.direction)) * shadow;
                half3 h = normalize(main.direction + v);
                half spec = pow(saturate(dot(n, h)), lerp(24.0, 96.0, _Shine)) * _Shine * shadow;
                half rim = pow(1.0 - saturate(dot(n, v)), 3.0) * 0.25;
                half3 colour = albedo * (lit + SampleSH(n)) + main.color * spec + rim * albedo + albedo * _Glow;
                return half4(MixFog(colour, IN.fog), 1);
            }
            ENDHLSL
        }

        UsePass "Universal Render Pipeline/Lit/ShadowCaster"
        UsePass "Universal Render Pipeline/Lit/DepthOnly"
    }
}
