// Pirate Cove v7 coastal water (delivered with the v7 pack; Water/CoastalWater.shader). Used by ThemedCourses.Cove for the
// sea round a course and its water hazards. Shore masks (R shallows, G foam) are baked into the sea mesh's vertex colours.
// Stylized opaque water for URP 17.3. No scene-depth/color copies or reflection camera.
Shader "PuttParty/CoastalWater"
{
 Properties
 {
  _DeepColor("Deep water", Color)=(0.025,0.25,0.34,1)
  _ShallowColor("Shallows", Color)=(0.08,0.66,0.65,1)
  _HorizonColor("Horizon reflection tint", Color)=(0.34,0.65,0.72,1)
  _FoamColor("Foam", Color)=(0.76,0.94,0.88,1)
  _SunTint("Broad sun highlight", Color)=(1,0.89,0.66,1)
  _ShallowFactor("Unpainted water shallows", Range(0,1))=0.3
  _UseVertexMasks("Use R=shallows G=foam masks", Range(0,1))=0
  _RippleScale("Ripple frequency / meter", Range(0.1,4))=1.4
  _RippleStrength("Normal ripple strength", Range(0,0.3))=0.12
  _WaveSpeed("Drift speed", Range(0,1))=0.24
  _HighlightStrength("Highlight strength", Range(0,0.5))=0.16
  _Gloss("Broad highlight exponent", Range(8,64))=24
  _FoamStrength("Shore foam amount", Range(0,1))=0.7
  _FogStrength("Scene fog blend", Range(0,1))=0.65
  [HideInInspector] _ArchFeet("Tidal arch feet in world XZ", Vector)=(0,0,0,0)
  _PreviewTime("Editor preview time (-1 = animated)", Float)=-1
 }
 SubShader
 {
  Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" "Queue"="Geometry" }
  HLSLINCLUDE
  #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
  CBUFFER_START(UnityPerMaterial)
   float4 _ArchFeet;
   half4 _DeepColor,_ShallowColor,_HorizonColor,_FoamColor,_SunTint;
   float _ShallowFactor,_UseVertexMasks,_RippleScale,_RippleStrength,_WaveSpeed;
   float _HighlightStrength,_Gloss,_FoamStrength,_FogStrength,_PreviewTime;
  CBUFFER_END
  float3 WaterPosition(float3 pos) {
    float3 ws=TransformObjectToWorld(pos);
    #if defined(_TIDAL_SURF)
      float t=(_PreviewTime>=0 ? _PreviewTime : _Time.y);
      // Fade displacement across the outer coarse grid so the horizon stays steady.
      float nearIsland=1-smoothstep(52.,70.,max(abs(ws.x),abs(ws.z)));
      ws.y+=nearIsland*(.065*sin(dot(ws.xz,float2(.39,.22))-t*.83)+.033*sin(dot(ws.xz,float2(-.25,.50))-t*1.07));
    #endif
    return ws;
  }
  #if defined(_TIDAL_SURF)
  float FoamHash(float2 p) {
    float3 q=frac(float3(p.xyx)*.1031);
    q+=dot(q,q.yzx+33.33);
    return frac((q.x+q.y)*q.z);
  }
  float FoamNoise(float2 p) {
    float2 cell=floor(p),f=frac(p);
    f=f*f*(3.-2.*f);
    return lerp(lerp(FoamHash(cell),FoamHash(cell+float2(1,0)),f.x),
                lerp(FoamHash(cell+float2(0,1)),FoamHash(cell+1),f.x),f.y);
  }
  float Breaker(float2 delta,float2 axes,float t) {
    float radius=length(delta/axes);
    float drift=t*.20;
    float lumps=FoamNoise(delta*1.12+float2(drift,-.5*drift));
    float flecks=FoamNoise(delta*3.15+float2(-.45*drift,drift));
    float inlet=sin(dot(delta,float2(.8,.64))+t*.38);
    float swash=radius+.19*(lumps-.5)+.046*inlet;
    float tide=sin(t*.96+.35*delta.x);
    float rim=swash-(1.03+.16*tide);
    float aa=clamp(fwidth(rim),.008,.15);
    float lip=1.-smoothstep(.012,.04+.07*lumps+aa,abs(rim));
    float film=(1.-smoothstep(.06,.23,rim))*smoothstep(-.035,.055,rim);
    float cells=smoothstep(.52,.71,.72*lumps+.28*flecks);
    float strands=1.-smoothstep(.012,.048+aa,abs(rim-.24-.16*(flecks-.5)));
    float gap=smoothstep(.22,.63,lumps+.11*inlet);
    return saturate(lip*(.16+.84*gap)+film*cells*.69+strands*cells*.76);
  }
  #endif
  ENDHLSL
  Pass
  {
   Name "CoastalWater"
   Tags { "LightMode"="UniversalForwardOnly" }
   ZWrite On Cull Back
   HLSLPROGRAM
   #pragma target 3.0
   #pragma shader_feature_local _TIDAL_SURF
   #pragma vertex vert
   #pragma fragment frag
   #pragma multi_compile_instancing
   #pragma multi_compile_fog
   #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Lighting.hlsl"
   struct Attributes { float4 positionOS:POSITION; half4 color:COLOR; UNITY_VERTEX_INPUT_INSTANCE_ID };
   struct Varyings {
    float4 positionCS:SV_POSITION; float3 positionWS:TEXCOORD0; half4 masks:COLOR; half fog:TEXCOORD1;
    UNITY_VERTEX_OUTPUT_STEREO
   };
   Varyings vert(Attributes i) {
    Varyings o=(Varyings)0;
    UNITY_SETUP_INSTANCE_ID(i);
    UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
    o.positionWS=WaterPosition(i.positionOS.xyz);
    o.positionCS=TransformWorldToHClip(o.positionWS);
    o.masks=i.color; o.fog=ComputeFogFactor(o.positionCS.z);
    return o;
   }
   half4 frag(Varyings i):SV_Target {
    UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
    float time=(_PreviewTime>=0 ? _PreviewTime : _Time.y)*_WaveSpeed;
    float2 p=i.positionWS.xz;
    float a=dot(p,float2(.8,.6))*_RippleScale+time;
    float b=dot(p,float2(-.6,.8))*_RippleScale*.63-time*.73;
    // Derivative filtering damps detail before it becomes subpixel in the headset.
    float filter=rcp(1+3*(fwidth(a)+fwidth(b)));
    float2 slope=(float2(.8,.6)*cos(a)+float2(-.6,.8)*cos(b)*.55)*_RippleStrength*filter;
    half3 n=normalize(float3(-slope.x,1,-slope.y));
    half3 v=SafeNormalize(GetWorldSpaceViewDir(i.positionWS));
    float broad=sin(p.x*.17+time*.21)*sin(p.y*.13-time*.17);
    half shallow=lerp(_ShallowFactor,i.masks.r,saturate(_UseVertexMasks));
    half3 color=lerp(_DeepColor.rgb,_ShallowColor.rgb,saturate(shallow+broad*.09));
    half ripple=.5+.5*sin(a+sin(b)*.6);
    color+=_HorizonColor.rgb*(ripple-.5)*.075*filter;
    half fresnel=pow(1-saturate(dot(n,v)),4);
    color=lerp(color,_HorizonColor.rgb,fresnel*.52);
    Light sun=GetMainLight();
    half3 h=SafeNormalize(v+sun.direction);
    half spec=pow(saturate(dot(n,h)),_Gloss)*_HighlightStrength*saturate(sun.direction.y*4);
    color+=_SunTint.rgb*spec;
    half shore=saturate(i.masks.g)*saturate(_UseVertexMasks);
    half wash=.35+.65*smoothstep(.15,.85,.5+.5*sin(a*.7+b*.4-time*.8));
    half foam=smoothstep(.25,.8,shore)*wash*_FoamStrength;
    #if defined(_TIDAL_SURF)
      float2 left=p-_ArchFeet.xy,right=p-_ArchFeet.zw;
      // Only shade breakers in the small patch of lagoon containing the two feet.
      if (min(dot(left,left),dot(right,right))<49) {
        float t=(_PreviewTime>=0 ? _PreviewTime : _Time.y);
        float breakers=max(Breaker(left,float2(3.45,2.92),t),Breaker(right,float2(3.05,2.75),t+.83));
        foam=max(foam,breakers*.94);
        float shelf=1-smoothstep(.85,1.85,min(length(left/float2(3.45,2.92)),length(right/float2(3.05,2.75))));
        color=lerp(color,_ShallowColor.rgb,shelf*.48);
      }
    #endif
    color=lerp(color,_FoamColor.rgb,saturate(foam));
    color=lerp(color,MixFog(color,i.fog),_FogStrength);
    return half4(color,1);
   }
   ENDHLSL
  }
  Pass
  {
   Name "DepthOnly"
   Tags { "LightMode"="DepthOnly" }
   ZWrite On ColorMask 0 Cull Back
   HLSLPROGRAM
   #pragma target 3.0
   #pragma shader_feature_local _TIDAL_SURF
   #pragma vertex DepthVert
   #pragma fragment DepthFrag
   #pragma multi_compile_instancing
   struct Attributes { float4 positionOS:POSITION; UNITY_VERTEX_INPUT_INSTANCE_ID };
   struct Varyings { float4 positionCS:SV_POSITION; UNITY_VERTEX_OUTPUT_STEREO };
   Varyings DepthVert(Attributes i) {
    Varyings o=(Varyings)0; UNITY_SETUP_INSTANCE_ID(i); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
    o.positionCS=TransformWorldToHClip(WaterPosition(i.positionOS.xyz));return o;
   }
   half4 DepthFrag(Varyings i):SV_Target { UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);return 0; }
   ENDHLSL
  }
 }
 Fallback Off
}

