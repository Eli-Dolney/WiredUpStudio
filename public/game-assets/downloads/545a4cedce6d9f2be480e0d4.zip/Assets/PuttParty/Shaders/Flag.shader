// A pin flag: unlit cloth that ripples away from the pole (UV u = 0 at the pole, so the wave grows
// with u), shaded in its folds, with the hole number in a white disc. The number comes from a digits
// atlas (_Digits, 6 x 4 cells holding 1..24); _Cell picks one (number - 1, or -1 for a plain flag) and
// is set per flag by FlagLift. From behind the number is unmirrored so it reads from both sides.
Shader "PuttParty/Flag"
{
    Properties
    {
        _BaseColor ("Color", Color) = (0.9, 0.15, 0.15, 1)
        _Digits ("Digits Atlas", 2D) = "black" {}
        _Cell ("Number Cell", Float) = -1
        _Amplitude ("Wave Amplitude", Float) = 0.022
        _Frequency ("Wave Frequency", Float) = 9
        _Speed ("Wave Speed", Float) = 5
    }
    SubShader
    {
        Tags { "RenderType"="Opaque" "RenderPipeline"="UniversalPipeline" "Queue"="Geometry" }
        Cull Off

        Pass
        {
            Name "Forward"
            Tags { "LightMode"="UniversalForward" }
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #pragma multi_compile_fog
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"

            TEXTURE2D(_Digits); SAMPLER(sampler_Digits);
            CBUFFER_START(UnityPerMaterial)
                half4 _BaseColor;
                float4 _Digits_ST;
                float _Cell, _Amplitude, _Frequency, _Speed;
            CBUFFER_END

            struct Attributes { float4 positionOS : POSITION; float2 uv : TEXCOORD0; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct Varyings { float4 positionHCS : SV_POSITION; float2 uv : TEXCOORD0; float shade : TEXCOORD1; half fog : TEXCOORD2; UNITY_VERTEX_OUTPUT_STEREO };

            Varyings vert (Attributes IN)
            {
                Varyings OUT;
                UNITY_SETUP_INSTANCE_ID(IN);
                UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(OUT);
                float3 p = IN.positionOS.xyz;
                float u = IN.uv.x, v = IN.uv.y, t = _Time.y * _Speed;
                // Two travelling waves (a slow billow and a faster flutter) growing away from the pole.
                float a1 = u * _Frequency - t, a2 = u * _Frequency * 2.3 - t * 1.7 + v * 2.5;
                float reach = u * (0.6 + 0.4 * u);
                p.z += (sin(a1) + 0.35 * sin(a2)) * _Amplitude * reach;
                p.x -= (1 - cos(a1)) * _Amplitude * 0.25 * reach;   // the cloth shortens a little as it folds
                p.y -= u * u * 0.012;                                 // and droops at the fly end
                OUT.positionHCS = TransformObjectToHClip(p);
                OUT.uv = IN.uv;
                OUT.shade = 0.84 + (cos(a1) + 0.35 * cos(a2)) * 0.12 * (0.3 + u);
                OUT.fog = ComputeFogFactor(OUT.positionHCS.z);
                return OUT;
            }

            half4 frag (Varyings IN, bool front : SV_IsFrontFace) : SV_Target
            {
                half3 colour = _BaseColor.rgb;
                if (_Cell >= 0)
                {
                    // The disc, round on the 3:2 cloth, a little toward the fly end.
                    float2 p = (IN.uv - float2(0.55, 0.5)) * float2(1.5, 1.0);
                    float d = length(p);
                    half disc = 1 - smoothstep(0.31, 0.325, d);
                    float2 local = p / 0.62 + 0.5;
                    if (!front) local.x = 1 - local.x;
                    float cell = round(_Cell);
                    float col = fmod(cell, 6), row = floor(cell / 6);
                    float2 auv = float2((col + local.x) / 6.0, 1 - (row + 1 - local.y) / 4.0);
                    half digit = disc * SAMPLE_TEXTURE2D(_Digits, sampler_Digits, auv).r;
                    colour = lerp(colour, half3(0.98, 0.97, 0.94), disc);
                    colour = lerp(colour, _BaseColor.rgb * 0.85, digit);
                }
                return half4(MixFog(colour * IN.shade, IN.fog), 1);
            }
            ENDHLSL
        }
    }
}
