Shader "PuttParty/KrakenRipple"
{
    SubShader
    {
        Tags { "RenderPipeline"="UniversalPipeline" "Queue"="Transparent" "RenderType"="Transparent" }
        Pass
        {
            Blend SrcAlpha OneMinusSrcAlpha
            Cull Off ZWrite Off
            HLSLPROGRAM
            #pragma vertex vert
            #pragma fragment frag
            #pragma multi_compile_instancing
            #include "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Core.hlsl"
            struct A { float4 p:POSITION; float2 uv:TEXCOORD0; half4 c:COLOR; UNITY_VERTEX_INPUT_INSTANCE_ID };
            struct V { float4 p:SV_POSITION; float2 uv:TEXCOORD0; half4 c:COLOR; UNITY_VERTEX_OUTPUT_STEREO };
            V vert(A i)
            {
                V o=(V)0; UNITY_SETUP_INSTANCE_ID(i); UNITY_INITIALIZE_VERTEX_OUTPUT_STEREO(o);
                float3 w=TransformObjectToWorld(i.p.xyz);
                w.y=-.085+.065*sin(dot(w.xz,float2(.39,.22))-_Time.y*.83)+.033*sin(dot(w.xz,float2(-.25,.50))-_Time.y*1.07);
                o.p=TransformWorldToHClip(w);o.uv=i.uv*2-1;o.c=i.c;return o;
            }
            half4 frag(V i):SV_Target
            {
                UNITY_SETUP_STEREO_EYE_INDEX_POST_VERTEX(i);
                float radius=length(i.uv), a=atan2(i.uv.y,i.uv.x);
                float ring=abs(radius-.73-.032*sin(4*a));
                float alpha=(1-smoothstep(.025,.055+fwidth(radius),ring))*smoothstep(-.65,.35,sin(3*a+.4)+.5*sin(5*a));
                return half4(i.c.rgb,i.c.a*alpha);
            }
            ENDHLSL
        }
    }
}

